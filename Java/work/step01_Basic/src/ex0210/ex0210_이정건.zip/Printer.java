package ex0210.과제;
/**
 * 주제: println() 메소드를 int, boolean, double, String 타입의 파라미터를 사용하도록 오버로딩
 *       및 객체를 생성하지 않고도 메소드에 접근할 수 있도록 수정 (Exer16~17)
 * 작성일: 260210
 * 작성자: 이정건
 * */
public class Printer {
	
	public static void println(int value) {}
	public static void println(boolean value) {}
	public static void println(double value) {}
	public static void println(String value) {}
}
