package ex0210.과제;

public class Exer13_14 {
	
	public void main(String[] args) {
		Member member = new Member("홍길동", "hong");
		System.out.println("이름: " + member.getName());
		System.out.println("아이디: " + member.getId());
	}
}
