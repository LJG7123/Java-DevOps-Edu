package ex0205.과제;
/**
 * 주제: 코드의 실행 결과를 예측
 * 작성일: 260205
 * 작성자: 이정건
 *  
 * */
public class Exercise06 {

	public static void main(String[] args) {
		int[][] array = { { 95, 86 }, { 83, 92, 96 }, { 78, 83, 93, 87, 88 } };
		System.out.println(array.length); // 3
		System.out.println(array[2].length); // 5
	}

}
